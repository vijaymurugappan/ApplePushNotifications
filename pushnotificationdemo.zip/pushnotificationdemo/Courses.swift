//
//  Courses.swift
//  pushnotificationdemo
//
//  Created by Arun Balaji on 4/17/17.
//  Copyright © 2017 Vijay Murugappan Subbiah. All rights reserved.
//

import UIKit

class Courses: NSObject {
    
    var CourseCode = String()
    var CourseName = String()
    var CourseDate = String()
    
    init(coursecode:String , coursename:String , coursedate:String) {
        self.CourseCode = coursecode
        self.CourseName = coursename
        self.CourseDate = coursedate
    }
}
