//
//  CourseTableViewController.swift
//  pushnotificationdemo
//
//  Created by Arun Balaji on 4/17/17.
//  Copyright © 2017 Vijay Murugappan Subbiah. All rights reserved.
//

import UIKit

class CourseTableViewController: UITableViewController {

    var course = [Courses]()
    //var time = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getCourses()
        //convertToTime(_timeStr: "16:40")
    }
    
    

    // MARK: - Table view data source
    
    func getCourses() {
        //let path = NSBundle.mainBundle().pathForResource("AttractionLists", ofType: "plist")!
        let path = Bundle.main.path(forResource: "Courses", ofType: "plist")!
        let courseArray:NSArray = NSArray(contentsOfFile:path)!
        
        for dict in courseArray as! [[String:Any]] {
            let course_code = dict["Course Code"] as! String
            let course_name = dict["Course Name"] as! String
            let course_date = dict["Course Date"] as! String
            course.append(Courses(coursecode: course_code, coursename: course_name, coursedate: course_date))
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return course.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        let cell:CourseTableViewCell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! CourseTableViewCell
        let courses:Courses = course[indexPath.item]
        cell.TitleCell.text = courses.CourseCode
        cell.SubTitleCell.text = courses.CourseName
        cell.TimeCell.text = courses.CourseDate
//        for str in time {
//            
//        }
        return cell
    }
    
//    func appendTime(_tm:String)
//    {
//        time.append(_tm)
//        print(time)
//        return _tm
//    }
//    func convertToTime(_timeStr:String) -> String {
//        let inFormatter = DateFormatter()
//        inFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale!
//        inFormatter.dateFormat = "HH:mm"
//        
//        let outFormatter = DateFormatter()
//        outFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale!
//        outFormatter.dateFormat = "hh:mm"
//        
//        let date = inFormatter.date(from: _timeStr)!
//        let outStr = outFormatter.string(from: date)
//        return outStr
//    }

}
