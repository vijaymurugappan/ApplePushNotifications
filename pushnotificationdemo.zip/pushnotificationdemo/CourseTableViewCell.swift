//
//  CourseTableViewCell.swift
//  pushnotificationdemo
//
//  Created by Arun Balaji on 4/17/17.
//  Copyright © 2017 Vijay Murugappan Subbiah. All rights reserved.
//

import UIKit

class CourseTableViewCell: UITableViewCell {

    //var courseTimings = [String]()
    //var i:Int = 0
    
    @IBOutlet weak var TitleCell: UILabel!
    @IBOutlet weak var SubTitleCell: UILabel!
    @IBOutlet weak var TimeCell: UILabel!
    @IBOutlet weak var enrollChange: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    @IBAction func enrollClicked(_ sender: UIButton) {
        enrollChange.setTitle("ENROLLED", for: .normal)
        enrollChange.isEnabled = false
        //courseTimings.append(self.TimeCell.text!)
        writeToFile(_CTIME: self.TimeCell.text!)
        //print(courseTimings)
    }
    
    func writeToFile(_CTIME:String) {
        var newTime = _CTIME
        var oldTime = String()
        //let newStr = String()
        //var i:Int = 0
        //courseTimings.append(_CTIME)
        let filename = "courses"
        let documentUrl = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileUrl = documentUrl.appendingPathComponent(filename).appendingPathExtension("txt")
        print("file path \(fileUrl.path)")
        
        let filenameC = "courses"
        let documentUrlC = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileUrlC = documentUrlC.appendingPathComponent(filenameC).appendingPathExtension("txt")
        print("file path \(fileUrlC.path)")
//        if(i == 0)
//        {
//        do {
//            try newStr.write(to: fileUrl, atomically: true, encoding: String.Encoding.utf8)
//            //i += 1;
//        } catch let error as NSError {
//            print("Write Error")
//            print(error)
//        }
//        }
        
//        else {
        do {
            oldTime = try! String(contentsOf: fileUrl, encoding: String.Encoding.utf8)
            newTime.append("\n\(oldTime)")
            print(newTime)
            
        }
        
    
        
        do {
            try newTime.write(to: fileUrl, atomically: true, encoding: String.Encoding.utf8)
            
        } catch let error1 as NSError {
            print("Write Error")
            print(error1)
        }
        //}
        //}
        //print(courseTimings)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
}
