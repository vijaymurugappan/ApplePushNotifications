//
//  ViewController.swift
//  pushnotificationdemo
//
//  Created by Arun Balaji on 4/19/17.
//  Copyright © 2017 Vijay Murugappan Subbiah. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
